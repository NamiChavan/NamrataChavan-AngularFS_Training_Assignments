import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({

  providedIn: 'root'

})

export class AuthtokenService {

  constructor(private httpObj: HttpClient) {

  }

  getTokenForValidUser(uid:string, pwd:string) : Observable<any>

  {

    let userObj:any = { "email": uid,   "password": pwd  };

    let authUrl:string  = "http://localhost:4200/login";

    return this.httpObj.post(authUrl, userObj);

  }



}

